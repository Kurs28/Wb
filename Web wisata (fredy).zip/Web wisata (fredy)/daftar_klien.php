<title>Client</title>
<div class="wisata">

    <div class="paket">
        <div class="kartu">
            <img src="images/orang-1.jpg"  widht ="300px" height="300px"  alt="">
            <h3>Julian Smith</h3>
            <p>University of Auckland</p>
           
        </div>
        <div class="kartu">
            <img src="images/orang-2.jpg"  widht ="300px" height="300px" alt="">
            <h3>John McCarty</h3>
            <p>The University of Oxford</p>
        </div>                      
        <div class="kartu">
            <img src="images/orang-3.jpg" widht ="300px" height="300px" alt="">
            <h3>Fred O'Connor</h3>
            <p>The University of Sydney</p>
           
        </div>
        <div class="kartu">
            <img src="images/orang-4.jpg" widht ="300px" height="300px" alt="">
            <h3>Jane Doe</h3>
            <p>The University of Melbourne</p>

        </div>
        <div class="kartu">
            <img src="images/orang-5.jpg" widht ="300px" height="300px" alt="">
            <h3>Jack Sparrow</h3>
            <p>University of Alberta</p>
        </div>
        <div class="kartu">
            <img src="images/orang-6.jpg" widht ="300px" height="300px" alt="">
            <h3>John Carter</h3>
            <p>University of Toronto</p>
        </div>
    </div>

</div>
