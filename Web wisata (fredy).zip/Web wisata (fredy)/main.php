<title>Home</title>
<h2>Welcome Traveler</h2>

<div class="wisata">

    <div class="paket">
        <div class="kartu">
            <img src="images/paket-1.jpg"  widht ="300px" height="300px"  alt="">
            <h3>Paket A</h3>
            <p>Wisata 4 jam</p>
            <a href="index.php?page=order_input">Pesan Sekarang</a>
        </div>
        <div class="kartu">
            <img src="images/paket-2.jpg"  widht ="300px" height="300px" alt="">
            <h3>Paket B</h3>
            <p>Wisata 8 jam</p>
            <a href="index.php?page=order_input">Pesan Sekarang</a>
        </div>
        <div class="kartu">
            <img src="images/paket-3.jpg" widht ="300px" height="300px" alt="">
            <h3>Paket C</h3>
            <p>Wisata 12 jam</p>
            <a href="index.php?page=order_input">Pesan Sekarang</a>
        </div>
        <div class="kartu">
            <img src="images/paket-4.jpg" widht ="300px" height="300px" alt="">
            <h3>Paket D</h3>
            <p>Wisata 16 jam</p>
            <a href="index.php?page=order_input">Pesan Sekarang</a>
        </div>

    </div>

    <div class="video">
        
        <iframe width="100%" height="200" src="https://www.youtube.com/embed/MUH3S6RMgAY" ></iframe>
        <iframe width="100%" height="200" src="https://www.youtube.com/embed/wC8hyxpbMHM" ></iframe>
        <iframe width="100%" height="200" src="https://www.youtube.com/embed/kVxTrhojpFI" ></iframe>
 
    </div>




</div>