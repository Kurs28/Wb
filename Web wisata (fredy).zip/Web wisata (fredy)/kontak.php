<title>Kontak Kami</title>
<link rel="stylesheet" href="css/style.css">
<section class="contact-form">
            <h1>Kontak Kami</h1>
            <form action="contact.php" method="post">
                <label for="name">Nama:</label>
                <input type="text" id="name" name="name" required><br><br>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br><br>
                <label for="message">Pesan:</label>
                <textarea id="message" name="message" required></textarea><br><br>
                <input type="submit" value="Kirim Pesan">
            </form>
        </section>