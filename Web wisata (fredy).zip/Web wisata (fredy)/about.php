<link rel="stylesheet" href="css/style.css">
<title>about</title>
<main>
        <section id="about">
            <h1>Tentang Kami</h1>
            <p>Selamat Datang Di Halaman Tentang!</p>
                <img src="images/profile.png" alt="Profile Picture">
            <p>Dibangun dari cinta akan petualangan dan keindahan alam, perusahaan wisata kami bermula dari sebuah impian sederhana: untuk membawa orang-orang ke tempat-tempat yang belum pernah mereka jelajahi sebelumnya. Berawal dari sebuah kantor kecil di pinggiran kota, kami tumbuh menjadi salah satu pemimpin industri wisata global.</p>
            <h2>Visi</h2>
            <p>Menjadi pilihan utama bagi para petualang yang menginginkan pengalaman wisata yang tak terlupakan di destinasi-destinasi eksotis di seluruh dunia.</p>
            <h2>Misi</h2>
            <ul>
                <p><li>Memberikan Pengalaman. </li></p>
                <p><li>Inovasi Tanpa Henti. </li></p>
                
            </ul>
        </section>
    </main>