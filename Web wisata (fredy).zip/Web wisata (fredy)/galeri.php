<title>Galeri foto</title>
<div class="wisata">

    <div class="paket">
        <div class="kartu">
            <img src="images/paket-1.jpg"  widht ="300px" height="300px"  alt="">
           
        </div>
        <div class="kartu">
            <img src="images/paket-2.jpg"  widht ="300px" height="300px" alt="">
           
        </div>
        <div class="kartu">
            <img src="images/paket-3.jpg" widht ="300px" height="300px" alt="">
           
        </div>
        <div class="kartu">
            <img src="images/paket-4.jpg" widht ="300px" height="300px" alt="">

        </div>
        <div class="kartu">
            <img src="images/gambar-1.jpg" widht ="300px" height="300px" alt="">
        </div>
        <div class="kartu">
            <img src="images/gambar-2.jpg" widht ="300px" height="300px" alt="">
        </div>
    </div>

</div>
