<?php 

$koneksi = new PDO("mysql:host=localhost;dbname=dbwisata","root","");