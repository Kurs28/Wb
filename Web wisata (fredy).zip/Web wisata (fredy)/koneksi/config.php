<?php 

$koneksi = new PDO("mysql:host=localhost;dbname=pengguna","root","");